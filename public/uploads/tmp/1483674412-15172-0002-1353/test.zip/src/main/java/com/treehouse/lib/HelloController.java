package com.treehouse.lib;

/**
 * Created by admin on 2016-12-27.
 */

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

/*
@RestController
public class HelloController {

    @RequestMapping("/")
    public String index() {
        return "Hello World";
    }

}*/