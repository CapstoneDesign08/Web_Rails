class Page < ActiveRecord::Base
end
